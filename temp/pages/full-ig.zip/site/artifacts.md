# Artifacts Summary - Guide documentaire CPage des guides d'implémentaion FHIR v0.1.0

* [**Table of Contents**](toc.md)
* **Artifacts Summary**

## Artifacts Summary

This page provides a list of the FHIR artifacts defined as part of this implementation guide.

